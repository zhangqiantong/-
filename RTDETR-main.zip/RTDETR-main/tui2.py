import warnings
warnings.filterwarnings('ignore')
from ultralytics import RTDETR
import torch
from torchvision.ops import nms
import os
from PIL import Image
import torchvision.transforms as T
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from pathlib import Path
import json
from tqdm import tqdm

# 类别名称列表
class_names = [
    'subglottic edema',
    'ventricular obliteration',
    'erythema/hyperemia',
    'vocal fold edema',
    'diffuse laryngeal edema',
    'posterior commissure hypertrophy',
    'granulation tissue',
    'thick endolaryngeal mucus2'
]

# 从文件中加载最佳阈值
def load_best_thresholds(thresholds_file):
    thresholds = {}
    with open(thresholds_file, 'r') as f:
        for line in f:
            if line.strip():
                try:
                    class_id, key, value = line.strip().split(': ')
                    class_id = int(class_id.split(' ')[1])
                    if class_id not in thresholds:
                        thresholds[class_id] = {}
                    thresholds[class_id][key.split(' ')[-1]] = float(value)
                except ValueError:
                    print(f"Error parsing line: {line.strip()}")
                    continue
    return thresholds

# 自定义的NMS函数（例如，Soft-NMS）
def special_nms_for_diffuse_laryngeal_edema(predictions, iou_threshold):
    boxes = predictions[:, :4]
    scores = predictions[:, 4]
    indices = nms(boxes, scores, iou_threshold)
    return indices

# 定义类别特定的NMS函数
def apply_class_specific_nms(predictions, iou_thresholds, special_class_id=None, special_nms_func=None):
    kept_predictions = []

    # 先处理特定类别的NMS
    if special_class_id is not None and special_nms_func is not None:
        special_class_mask = predictions[:, 5] == special_class_id
        special_class_predictions = predictions[special_class_mask]

        if special_class_predictions.size(0) > 0:
            indices = special_nms_func(special_class_predictions, iou_thresholds[special_class_id])
            kept_predictions.append(special_class_predictions[indices])
            predictions = predictions[~special_class_mask]  # 移除已处理的特定类别

    # 处理其他类别的NMS
    for class_id, iou_threshold in iou_thresholds.items():
        if class_id == special_class_id:
            continue
        class_mask = predictions[:, 5] == class_id
        class_predictions = predictions[class_mask]

        if class_predictions.size(0) > 0:
            boxes = class_predictions[:, :4]
            scores = class_predictions[:, 4]
            indices = nms(boxes, scores, iou_threshold)
            kept_predictions.append(class_predictions[indices])

    return torch.cat(kept_predictions) if kept_predictions else torch.empty((0, 6))

# 图像预处理
transform = T.Compose([
    T.Resize((640, 640)),
    T.ToTensor(),
])

def preprocess_image(image_path):
    image = Image.open(image_path).convert("RGB")
    image = transform(image).unsqueeze(0)  # 增加批次维度
    return image

# 显示和保存预测结果
def display_predictions(image_path, predictions, class_names, save_dir):
    image = Image.open(image_path).convert("RGB")
    plt.figure(figsize=(12, 8))
    plt.imshow(image)
    ax = plt.gca()

    for prediction in predictions:
        x1, y1, x2, y2, score, class_id = prediction
        if score > 0.2:  # 根据需要设置分数阈值
            rect = patches.Rectangle((x1, y1), x2 - x1, y2 - y1, linewidth=2, edgecolor='r', facecolor='none')
            ax.add_patch(rect)
            plt.text(x1, y1, f"{class_names[int(class_id)]}: {score:.2f}", bbox=dict(facecolor='yellow', alpha=0.5))

    plt.axis('off')

    # 保存结果
    save_path = os.path.join(save_dir, os.path.basename(image_path))
    plt.savefig(save_path)
    plt.close()

# 推理并保存结果
def process_folder_images(folder_path, model, thresholds, save_dir='results'):
    os.makedirs(save_dir, exist_ok=True)
    image_paths = load_images_from_folder(folder_path)

    all_predictions = []

    for image_path in tqdm(image_paths, desc="Processing images"):
        image = preprocess_image(image_path)

        results = model.predict(source=image_path, save=False, conf=0.2)[0]  # 进行推理
        predictions = results.boxes.xyxy.cpu()  # 获取预测框的xyxy坐标
        scores = results.boxes.conf.cpu()  # 获取预测的置信度分数
        classes = results.boxes.cls.cpu()  # 获取预测的类别

        # 将预测结果组合成一个张量
        predictions = torch.cat((predictions, scores.unsqueeze(1), classes.unsqueeze(1)), dim=1)

        filtered_predictions = []
        for class_id, params in thresholds.items():
            class_mask = predictions[:, 5] == class_id
            class_predictions = predictions[class_mask]

            if class_predictions.size(0) > 0:
                scores = class_predictions[:, 4]
                keep = scores > params['conf_threshold']
                class_predictions = class_predictions[keep]

                if class_predictions.size(0) > 0:
                    if class_id == 4:  # 对于特定的类使用自定义NMS
                        indices = special_nms_for_diffuse_laryngeal_edema(class_predictions, params['iou_threshold'])
                    else:
                        boxes = class_predictions[:, :4]
                        scores = class_predictions[:, 4]
                        indices = nms(boxes, scores, params['iou_threshold'])
                    class_predictions = class_predictions[indices]

                filtered_predictions.append(class_predictions)

        if filtered_predictions:
            filtered_predictions = torch.cat(filtered_predictions) if len(filtered_predictions) > 1 else filtered_predictions[0]
            display_predictions(image_path, filtered_predictions, class_names, save_dir)
            # 生成 COCO 格式的预测结果
            image_id = int(os.path.splitext(os.path.basename(image_path))[0])
            for pred in filtered_predictions:
                x1, y1, x2, y2, score, class_id = pred
                width = x2 - x1
                height = y2 - y1
                all_predictions.append({
                    "image_id": image_id,
                    "category_id": int(class_id),
                    "bbox": [x1.item(), y1.item(), width.item(), height.item()],
                    "score": score.item()
                })

    with open(os.path.join(save_dir, 'coco_predictions.json'), 'w') as f:
        json.dump(all_predictions, f)

def load_images_from_folder(folder_path):
    image_paths = list(Path(folder_path).glob('*.jpg')) + list(Path(folder_path).glob('*.png'))
    return image_paths

if __name__ == '__main__':
    model = RTDETR('/root/autodl-tmp/RTDETR-main/runs/train/exp59/weights/best.pt')  # 选择您的model.pt路径

    folder_path = '/root/autodl-tmp/data/yolo_nc=9/images/val'  # 替换为您的图片文件夹路径
    thresholds = load_best_thresholds('/root/autodl-tmp/sa/best_thresholds.txt')  # 替换为您的最佳阈值文件路径

    process_folder_images(
        folder_path, model, thresholds,
        save_dir='/root/autodl-tmp/nms-test'  # 替换为您的保存目录路径
    )
