import warnings
warnings.filterwarnings('ignore')
from ultralytics import RTDETR

if __name__ == '__main__':
    model = RTDETR('/root/autodl-tmp/RTDETR-main/runs/train/对比实验exp67/weights/best.pt') # select your model.pt path
    model.predict(source='/root/autodl-tmp/data/yolo_nc=9/images/val',
                  project='runs/detect',
                  name='exp',
                  save=True,
                  device='0',
                  save_txt=True,
                  iou=0.2,
                  conf=0.2
                  #visualize=True # visualize model features maps
                  )