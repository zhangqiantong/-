import warnings

warnings.filterwarnings('ignore')
from ultralytics import RTDETR
import torch
from torchvision.ops import nms
from sklearn.metrics import precision_recall_fscore_support
import numpy as np
from torch.utils.data import DataLoader, Dataset
from PIL import Image
import torchvision.transforms as T
import os
from scipy.optimize import dual_annealing
from tqdm import tqdm
import logging
import contextlib
import sys

# 禁止其他模块的输出
logging.getLogger().setLevel(logging.CRITICAL)


# 定义抑制输出的上下文管理器
@contextlib.contextmanager
def suppress_stdout():
    with open(os.devnull, 'w') as devnull:
        old_stdout = sys.stdout
        sys.stdout = devnull
        try:
            yield
        finally:
            sys.stdout = old_stdout


# 加载 YOLO 格式标签
def load_yolo_labels(label_path, img_width, img_height):
    if not os.path.exists(label_path):
        return np.empty((0, 5))  # 如果标签文件不存在，则返回空的数组
    labels = []
    with open(label_path, 'r') as file:
        for line in file.readlines():
            class_id, x_center, y_center, width, height = map(float, line.strip().split())
            x_center *= img_width
            y_center *= img_height
            width *= img_width
            height *= img_height
            x1 = x_center - width / 2
            y1 = y_center - height / 2
            x2 = x_center + width / 2
            y2 = y_center + height / 2
            labels.append([x1, y1, x2, y2, class_id])
    return np.array(labels)


# 定义自定义数据集
class YoloDataset(Dataset):
    def __init__(self, image_dir, label_dir, transform=None):
        self.image_dir = image_dir
        self.label_dir = label_dir
        self.transform = transform
        self.image_files = [f for f in os.listdir(image_dir) if f.endswith('.jpg') or f.endswith('.png')]

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_path = os.path.join(self.image_dir, self.image_files[idx])
        label_path = os.path.join(self.label_dir, os.path.splitext(self.image_files[idx])[0] + '.txt')
        img = Image.open(img_path).convert('RGB')
        width, height = img.size
        labels = load_yolo_labels(label_path, width, height)

        if self.transform:
            img = self.transform(img)

        return img, labels, width, height  # 返回原始宽度和高度


# 自定义 collate_fn
def custom_collate_fn(batch):
    images, labels, widths, heights = zip(*batch)
    images = torch.stack(images, 0)
    return images, list(labels), widths, heights


# 图像预处理
transform = T.Compose([
    T.Resize((640, 640)),
    T.ToTensor(),
])

# 创建数据集和数据加载器
image_dir = '/root/autodl-tmp/data/yolo_nc=9/images/val'
label_dir = '/root/autodl-tmp/data/yolo_nc=9/labels/val'
batch_size = 32  # 调整 batch_size
dataset = YoloDataset(image_dir, label_dir, transform)
validation_loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, collate_fn=custom_collate_fn,
                               num_workers=4, pin_memory=True)

# 设置使用的GPU
gpu_id = 0
device = torch.device(f'cuda:{gpu_id}' if torch.cuda.is_available() else 'cpu')
torch.cuda.set_device(device)

# 加载模型
model_path = '/root/autodl-tmp/RTDETR-main/runs/train/MultiScale/weights/best.pt'
model = RTDETR(model_path)
model.to(device)


# 计算 IoU
def calculate_iou(pred_boxes, true_boxes):
    inter_x1 = torch.max(pred_boxes[:, None, 0], true_boxes[:, 0])
    inter_y1 = torch.max(pred_boxes[:, None, 1], true_boxes[:, 1])
    inter_x2 = torch.min(pred_boxes[:, None, 2], true_boxes[:, 2])
    inter_y2 = torch.min(pred_boxes[:, None, 3], true_boxes[:, 3])

    inter_area = torch.clamp(inter_x2 - inter_x1, min=0) * torch.clamp(inter_y2 - inter_y1, min=0)
    pred_area = (pred_boxes[:, 2] - pred_boxes[:, 0]) * (pred_boxes[:, 3] - pred_boxes[:, 1])
    true_area = (true_boxes[:, 2] - true_boxes[:, 0]) * (true_boxes[:, 3] - true_boxes[:, 1])

    iou = inter_area / (pred_area[:, None] + true_area - inter_area)
    return iou


# 计算 F1 分数
def compute_f1_score(predictions, ground_truths, iou_threshold=0.5):
    all_true_labels = []
    all_pred_labels = []

    for i, prediction in enumerate(predictions):
        if len(prediction) == 0 or len(ground_truths[i]) == 0:
            continue

        pred_boxes = torch.tensor(prediction[:, :4])
        pred_labels = torch.tensor(prediction[:, 5])

        true_boxes = torch.tensor(ground_truths[i][:, :4])
        true_labels = torch.tensor(ground_truths[i][:, 4])

        # Calculate IoU and determine true positives, false positives, false negatives
        ious = calculate_iou(pred_boxes, true_boxes)
        tp = (ious > iou_threshold).sum(dim=1) > 0

        # 确保标签数量一致
        true_positive_count = tp.sum().item()
        false_positive_count = len(tp) - true_positive_count
        false_negative_count = len(true_labels) - true_positive_count

        all_true_labels.extend([1] * true_positive_count + [0] * (false_positive_count + false_negative_count))
        all_pred_labels.extend([1] * true_positive_count + [0] * false_positive_count + [1] * false_negative_count)

    precision, recall, f1, _ = precision_recall_fscore_support(all_true_labels, all_pred_labels, average='binary')
    return f1


# 优化阈值函数
def optimize_thresholds_function(params, model, validation_loader, class_id):
    iou_threshold, conf_threshold = params
    predictions = []
    ground_truths = []

    for batch_idx, (images, targets, widths, heights) in enumerate(validation_loader):
        images = images.to(device)

        with torch.no_grad():
            with suppress_stdout():
                results = model.predict(source=images, save=False)

        for j, result in enumerate(results):
            boxes = result.boxes.xyxy.cpu()
            scores = result.boxes.conf.cpu()
            labels = result.boxes.cls.cpu()

            boxes[:, [0, 2]] *= widths[j] / 640
            boxes[:, [1, 3]] *= heights[j] / 640

            keep = (scores > conf_threshold) & (labels == class_id)
            boxes = boxes[keep]
            scores = scores[keep]
            labels = labels[keep]

            if len(boxes) > 0:
                keep = nms(boxes, scores, iou_threshold)
                boxes = boxes[keep]
                scores = scores[keep]
                labels = labels[keep]

            predictions.append(torch.cat((boxes, scores.unsqueeze(1), labels.unsqueeze(1)), dim=1).numpy())
        ground_truths.extend(targets)

    f1_score = compute_f1_score(predictions, ground_truths, iou_threshold)
    return -f1_score  # 由于优化函数是最小化损失，因此返回负的F1分数


# 优化阈值
def optimize_thresholds(model, validation_loader, num_classes, max_iterations=100, convergence_threshold=1e-4):
    best_thresholds = {}
    max_unchanged_iterations = 10

    for class_id in tqdm(range(num_classes), desc="Optimizing thresholds", leave=False):
        bounds = [(0.3, 0.8), (0.1, 0.9)]  # 边界
        iteration_counter = 0
        last_best_f1 = None
        unchanged_iterations = 0

        def convergence_callback(xk, fopt, *args):
            nonlocal iteration_counter, last_best_f1, unchanged_iterations
            iteration_counter += 1
            if last_best_f1 is not None and abs(last_best_f1 - fopt) < convergence_threshold:
                unchanged_iterations += 1
            else:
                unchanged_iterations = 0
            last_best_f1 = fopt
            return iteration_counter >= max_iterations or unchanged_iterations >= max_unchanged_iterations

        result = dual_annealing(optimize_thresholds_function, bounds, args=(model, validation_loader, class_id),
                                maxiter=max_iterations, callback=convergence_callback)
        best_thresholds[class_id] = {
            'iou_threshold': result.x[0],
            'conf_threshold': result.x[1],
            'f1_score': -result.fun
        }

    return best_thresholds


if __name__ == '__main__':
    model = RTDETR('/root/autodl-tmp/RTDETR-main/runs/train/MultiScale/weights/best.pt')

    num_classes = 8  # 根据您的数据集调整
    best_thresholds = optimize_thresholds(model, validation_loader, num_classes, max_iterations=100)

    # 保存阈值到文件
    with open('/root/autodl-tmp/sa/best_thresholds.txt', 'w') as f:
        for class_id, thresholds in best_thresholds.items():
            f.write(f"Class {class_id} Best IoU Threshold: {thresholds['iou_threshold']}\n")
            f.write(f"Class {class_id} Best Confidence Threshold: {thresholds['conf_threshold']}\n")
            f.write(f"Class {class_id} Best F1 Score: {thresholds['f1_score']}\n")
