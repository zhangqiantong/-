import warnings

warnings.filterwarnings('ignore')
from ultralytics import RTDETR
import torch
from torchvision.ops import nms
import os
from PIL import Image
import torchvision.transforms as T
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from pathlib import Path

# 类别名称列表
class_names = [
    '0',
    '1',
    '3',
    '5',
    '9',
    '13',
    '17',
    '18'
]

# 原图尺寸
original_width = 1335
original_height = 1080


# 自定义的NMS函数（例如，Soft-NMS）
def special_nms_for_diffuse_laryngeal_edema(predictions, iou_threshold):
    boxes = predictions[:, :4]
    scores = predictions[:, 4]
    indices = nms(boxes, scores, iou_threshold)
    return indices


# 定义类别特定的NMS函数
def apply_class_specific_nms(predictions, iou_thresholds, special_class_id=None, special_nms_func=None):
    kept_predictions = []

    # 先处理特定类别的NMS
    if special_class_id is not None and special_nms_func is not None:
        special_class_mask = predictions[:, 5] == special_class_id
        special_class_predictions = predictions[special_class_mask]

        if special_class_predictions.size(0) > 0:
            indices = special_nms_func(special_class_predictions, iou_thresholds[special_class_id])
            kept_predictions.append(special_class_predictions[indices])
            predictions = predictions[~special_class_mask]  # 移除已处理的特定类别

    # 处理其他类别的NMS
    for class_id, iou_threshold in iou_thresholds.items():
        if class_id == special_class_id:
            continue
        class_mask = predictions[:, 5] == class_id
        class_predictions = predictions[class_mask]

        if class_predictions.size(0) > 0:
            boxes = class_predictions[:, :4]
            scores = class_predictions[:, 4]
            indices = nms(boxes, scores, iou_threshold)
            kept_predictions.append(class_predictions[indices])

    return torch.cat(kept_predictions) if kept_predictions else torch.empty((0, 6))


# 图像预处理
transform = T.Compose([
    T.Resize((640, 640)),
    T.ToTensor(),
])


def preprocess_image(image_path):
    image = Image.open(image_path).convert("RGB")
    image = transform(image).unsqueeze(0)  # 增加批次维度
    return image


# 转换为YOLO格式的坐标并保存
def save_predictions_to_txt(predictions, class_names, txt_path):
    with open(txt_path, 'w') as f:
        for prediction in predictions:
            x1, y1, x2, y2, score, class_id = prediction

            # 计算中心点坐标和宽高
            x_center = (x1 + x2) / 2.0
            y_center = (y1 + y2) / 2.0
            width = x2 - x1
            height = y2 - y1

            # 归一化坐标到相对于原图尺寸的比例坐标
            x_center /= original_width
            y_center /= original_height
            width /= original_width
            height /= original_height

            # 写入txt文件
            f.write(f"{class_id} {x_center} {y_center} {width} {height}\n")


# 显示和保存预测结果
def display_predictions(image_path, predictions, class_names, save_dir, save_txt=False):
    image = Image.open(image_path).convert("RGB")
    plt.figure(figsize=(12, 8))
    plt.imshow(image)
    ax = plt.gca()

    for prediction in predictions:
        x1, y1, x2, y2, score, class_id = prediction

        # 打印中间结果
        print(f"Prediction: Class {class_id}, Score {score}, Box ({x1}, {y1}, {x2}, {y2})")

        # 检查并修正负数坐标
        x1, y1 = max(x1, 0), max(y1, 0)
        x2, y2 = max(x2, 0), max(y2, 0)

        if score > 0.5:  # 根据需要设置分数阈值
            rect = patches.Rectangle((x1, y1), x2 - x1, y2 - y1, linewidth=2, edgecolor='r', facecolor='none')
            ax.add_patch(rect)
            plt.text(x1, y1, f"{class_names[int(class_id)]}: {score:.2f}", bbox=dict(facecolor='yellow', alpha=0.5))

    plt.axis('off')

    # 保存结果图像
    save_path = os.path.join(save_dir, os.path.basename(image_path))
    plt.savefig(save_path)
    plt.close()

    # 保存结果为txt文件
    if save_txt:
        txt_path = os.path.join(save_dir, os.path.splitext(os.path.basename(image_path))[0] + '.txt')
        save_predictions_to_txt(predictions, class_names, txt_path)


# 推理并保存结果
def process_folder_images(folder_path, model, iou_thresholds, score_thresholds, special_class_id=None,
                          special_nms_func=None, save_dir='results', save_txt=False):
    os.makedirs(save_dir, exist_ok=True)
    image_paths = load_images_from_folder(folder_path)

    for image_path in image_paths:
        image = preprocess_image(image_path)

        results = model.predict(source=image_path, save=False, conf=0.2)[0]  # 进行推理
        predictions = results.boxes.xyxy.cpu()  # 获取预测框的xyxy坐标
        scores = results.boxes.conf.cpu()  # 获取预测的置信度分数
        classes = results.boxes.cls.cpu()  # 获取预测的类别

        # 将预测结果组合成一个张量
        predictions = torch.cat((predictions, scores.unsqueeze(1), classes.unsqueeze(1)), dim=1)

        filtered_predictions = filter_by_score_threshold(predictions, score_thresholds)
        if filtered_predictions.size(0) > 0:
            filtered_predictions = apply_class_specific_nms(filtered_predictions, iou_thresholds, special_class_id,
                                                            special_nms_func)

        if filtered_predictions.size(0) > 0:
            display_predictions(image_path, filtered_predictions, class_names, save_dir, save_txt)


# 根据类别设置IoU阈值和分数阈值
iou_thresholds = {
    0: 0.5,  # subglottic edema
    1: 0.5,  # ventricular obliteration
    2: 0.5,  # erythema/hyperemia
    3: 0.5,  # vocal fold edema
    4: 0.3,  # diffuse laryngeal edema (special)
    5: 0.5,  # posterior commissure hypertrophy
    6: 0.5,  # granulation tissue
    7: 0.5  # thick endolaryngeal mucus2
}

score_thresholds = {
    0: 0.2,  # subglottic edema
    1: 0.2,  # ventricular obliteration
    2: 0.2,  # erythema/hyperemia
    3: 0.2,  # vocal fold edema
    4: 0.3,  # diffuse laryngeal edema
    5: 0.2,  # posterior commissure hypertrophy
    6: 0.2,  # granulation tissue
    7: 0.2  # thick endolaryngeal mucus2
}


def filter_by_score_threshold(predictions, score_thresholds):
    filtered_predictions = []
    for class_id, score_threshold in score_thresholds.items():
        class_mask = predictions[:, 5] == class_id
        class_predictions = predictions[class_mask]

        if class_predictions.size(0) > 0:
            scores = class_predictions[:, 4]
            keep = scores > score_threshold
            filtered_predictions.append(class_predictions[keep])

    return torch.cat(filtered_predictions) if filtered_predictions else torch.empty((0, 6))


def load_images_from_folder(folder_path):
    image_paths = list(Path(folder_path).glob('*.jpg')) + list(Path(folder_path).glob('*.png'))
    return image_paths


if __name__ == '__main__':
    model = RTDETR('/home/zhangqiantong/RTDETR-main/runs/train/exp59/weights/best.pt')  # 选择您的model.pt路径

    folder_path = '/home/zhangqiantong/hp-tmp/score/images/test'  # 替换为您的图片文件夹路径
    process_folder_images(
        folder_path, model, iou_thresholds, score_thresholds,
        special_class_id=4, special_nms_func=special_nms_for_diffuse_laryngeal_edema,
        save_dir='/home/zhangqiantong/RTDETR-main/runs/yolo',  # 替换为您的保存目录路径
        save_txt=True  # 设置为True以保存结果为txt文件
    )
