import torch
import torch.onnx from /root/autodl-tmp/RTDETR-main import RTDETR  # 需要替换为你的RT-DETR模型文件路径和类名

# 加载训练好的模型
model = RTDETR()
model.load_state_dict(torch.load('/root/autodl-tmp/RTDETR-main/runs/train/exp59/weights/best.pt'))
model.eval()

# 输入示例
dummy_input = torch.randn(1, 3, 640, 640)  # 根据模型的输入尺寸调整

# 导出为ONNX格式
torch.onnx.export(
    model,
    dummy_input,
    "rtdetr.onnx",
    opset_version=11,
    input_names=['input'],
    output_names=['output'],
    dynamic_axes={'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}}
)

print("ONNX model has been exported successfully.")
