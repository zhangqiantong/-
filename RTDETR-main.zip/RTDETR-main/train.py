import warnings
warnings.filterwarnings('ignore')
from ultralytics import RTDETR

if __name__ == '__main__':
    model = RTDETR('/root/autodl-tmp/RTDETR-main/ultralytics/cfg/models/rt-detr/rtdetr-attention.yaml')
    # model.load('') # loading pretrain weights
    model.train(data='/root/autodl-tmp/data/project-tlj/my_data.yaml',
                cache=False,
                imgsz=640,
                epochs=200,
                batch=33,
                workers=4,
                device='0,1,2',
                #/ resume='/root/autodl-tmp/RTDETR-main/runs/train/exp69/weights/best.pt', # last.pt path
                project='runs/train',
                name='exp',
                )