import warnings

warnings.filterwarnings('ignore')
from ultralytics import RTDETR
import torch
from torchvision.ops import nms
import os
from PIL import Image
import torchvision.transforms as T
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from pathlib import Path

# 类别名称列表
class_names = [
    'subglottic edema',
    'ventricular obliteration',
    'erythema/hyperemia',
    'vocal fold edema',
    'diffuse laryngeal edema',
    'posterior commissure hypertrophy',
    'granulation tissue',
    'thick endolaryngeal mucus2'
]


# 自定义的NMS函数（例如，Soft-NMS）
def special_nms_for_diffuse_laryngeal_edema(predictions, iou_threshold):
    boxes = predictions[:, :4]
    scores = predictions[:, 4]
    indices = nms(boxes, scores, iou_threshold)
    return indices


# 定义类别特定的NMS函数
def apply_class_specific_nms(predictions, iou_thresholds, special_class_id=None, special_nms_func=None):
    kept_predictions = []

    # 先处理特定类别的NMS
    if special_class_id is not None and special_nms_func is not None:
        special_class_mask = predictions[:, 5] == special_class_id
        special_class_predictions = predictions[special_class_mask]

        if special_class_predictions.size(0) > 0:
            indices = special_nms_func(special_class_predictions, iou_thresholds[special_class_id])
            kept_predictions.append(special_class_predictions[indices])
            predictions = predictions[~special_class_mask]  # 移除已处理的特定类别

    # 处理其他类别的NMS
    for class_id, iou_threshold in iou_thresholds.items():
        if class_id == special_class_id:
            continue
        class_mask = predictions[:, 5] == class_id
        class_predictions = predictions[class_mask]

        if class_predictions.size(0) > 0:
            boxes = class_predictions[:, :4]
            scores = class_predictions[:, 4]
            indices = nms(boxes, scores, iou_threshold)
            kept_predictions.append(class_predictions[indices])

    return torch.cat(kept_predictions) if kept_predictions else torch.empty((0, 6))


# 图像预处理
transform = T.Compose([
    T.Resize((640, 640)),
    T.ToTensor(),
])


def preprocess_image(image_path):
    image = Image.open(image_path).convert("RGB")
    image = transform(image).unsqueeze(0)  # 增加批次维度
    return image


# 显示和保存预测结果
def display_predictions(image_path, predictions, class_names, save_dir):
    image = Image.open(image_path).convert("RGB")
    plt.figure(figsize=(12, 8))
    plt.imshow(image)
    ax = plt.gca()

    for prediction in predictions:
        x1, y1, x2, y2, score, class_id = prediction
        if score > 0.2:  # 根据需要设置分数阈值
            rect = patches.Rectangle((x1, y1), x2 - x1, y2 - y1, linewidth=2, edgecolor='r', facecolor='none')
            ax.add_patch(rect)
            plt.text(x1, y1, f"{class_names[int(class_id)]}: {score:.2f}", bbox=dict(facecolor='yellow', alpha=0.5))

    plt.axis('off')

    # 保存结果
    save_path = os.path.join(save_dir, os.path.basename(image_path))
    plt.savefig(save_path)
    plt.close()


# 推理并保存结果
def process_folder_images(folder_path, model, iou_thresholds, score_thresholds, special_class_id=None,
                          special_nms_func=None, save_dir='results'):
    os.makedirs(save_dir, exist_ok=True)
    image_paths = load_images_from_folder(folder_path)

    for image_path in image_paths:
        image = preprocess_image(image_path)

        results = model.predict(source=image_path, save=False, conf=0.2)[0]  # 进行推理
        predictions = results.boxes.xyxy.cpu()  # 获取预测框的xyxy坐标
        scores = results.boxes.conf.cpu()  # 获取预测的置信度分数
        classes = results.boxes.cls.cpu()  # 获取预测的类别

        # 将预测结果组合成一个张量
        predictions = torch.cat((predictions, scores.unsqueeze(1), classes.unsqueeze(1)), dim=1)

        filtered_predictions = []
        filtered = filter_by_score_threshold(predictions, score_thresholds)
        if filtered.size(0) > 0:
            filtered = apply_class_specific_nms(filtered, iou_thresholds, special_class_id, special_nms_func)
        filtered_predictions.append(filtered)

        if filtered_predictions:
            display_predictions(image_path, filtered_predictions[0], class_names, save_dir)


# 根据类别设置IoU阈值和分数阈值
iou_thresholds = {
    0: 0.1856177687644959,  # subglottic edema
    1: 0.1932556390762329,  # ventricular obliteration
    2: 0.19880366921424865,  # erythema/hyperemia
    3: 0.18059726059436797,  # vocal fold edema
    4: 0.18714827214480455,  # diffuse laryngeal edema (special)
    5: 0.1044518366456032,  # posterior commissure hypertrophy
    6: 0.1138858405683222,  # granulation tissue
    7: 0.118168069422245  # thick endolaryngeal mucus2
}

score_thresholds = {
    0: 0.1206418266592445,  # subglottic edema
    1: 0.18106526802311032,  # ventricular obliteration
    2: 0.15597553682077956,  # erythema/hyperemia
    3: 0.13100755033248717,  # vocal fold edema
    4: 0.4716392318335462,  # diffuse laryngeal edema
    5: 0.1964330218722303,  # posterior commissure hypertrophy
    6: 0.1327201264086055,  # granulation tissue
    7: 0.1289156626506024  # thick endolaryngeal mucus2
}


def filter_by_score_threshold(predictions, score_thresholds):
    filtered_predictions = []
    for class_id, score_threshold in score_thresholds.items():
        class_mask = predictions[:, 5] == class_id
        class_predictions = predictions[class_mask]

        if class_predictions.size(0) > 0:
            scores = class_predictions[:, 4]
            keep = scores > score_threshold
            filtered_predictions.append(class_predictions[keep])

    return torch.cat(filtered_predictions) if filtered_predictions else torch.empty((0, 6))


def load_images_from_folder(folder_path):
    image_paths = list(Path(folder_path).glob('*.jpg')) + list(Path(folder_path).glob('*.png'))
    return image_paths


if __name__ == '__main__':
    model = RTDETR('/root/autodl-tmp/RTDETR-main/runs/train/MultiScale/weights/best.pt')  # 选择您的model.pt路径

    folder_path = '/root/autodl-tmp/data/yolo_nc=9/images/val'  # 替换为您的图片文件夹路径
    process_folder_images(
        folder_path, model, iou_thresholds, score_thresholds,
        special_class_id=4, special_nms_func=special_nms_for_diffuse_laryngeal_edema,
        save_dir='/root/autodl-tmp/nms-test'  # 替换为您的保存目录路径
    )
